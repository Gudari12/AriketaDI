import { signal } from '@angular/core';
import { Component, inject } from '@angular/core';
import { Cliente } from '../cliente';

@Component({
  selector: 'app-opendata',
  imports: [],
  templateUrl: './opendata.html',
  styleUrl: './opendata.css',
})
export class Opendata {

  cliente = inject(Cliente);
  data: any = signal(null);
  hola = "as";

  constructor() {
    this.cliente.getEventos()
      .subscribe((response) => {
        this.data.set(response);
        console.log(this.data());
      });
  }
}
